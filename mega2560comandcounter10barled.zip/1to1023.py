import serial
import time

# Configure the serial port connection
# We use 'COM5' at 9600 speed to match the Arduino code
PORT = 'COM5'
BAUD_RATE = 9600

try:
    print(f"Opening connection to {PORT}...")
    arduino = serial.Serial(port=PORT, baudrate=BAUD_RATE, timeout=1)
    
    # Crucial: Arduinos reboot when Python connects. 
    # We must wait 2 seconds for the Mega 2560 to fully wake up before sending data.
    print("Waiting for Arduino to initialize...")
    time.sleep(2)
    print("Connected and ready!")

    # Loop from 1 up to 1023 (range stops right before 1024)
    for number in range(1, 1024):
        # Convert the number to text and add the newline '\n' marker
        text_message = f"{number}\n"
        
        # Send the encoded text down the USB cable
        arduino.write(text_message.encode('utf-8'))
        
        print(f"Sent: {number}")
        
        # Pause for 50 milliseconds (0.05 seconds) before the next number
        time.sleep(0.2)

    print("\nFinished sending all numbers!")

except serial.SerialException as e:
    print(f"\nError: Could not open {PORT}.")
    print("Make sure your Arduino Serial Monitor is CLOSED so Python can access the port.")
    print(f"Details: {e}")

finally:
    # Ensure the port is safely closed when the script ends
    if 'arduino' in locals() and arduino.is_open:
        arduino.close()
        print("Serial port safely closed.")
