// Define the 10 digital pins used for the 10-bar LED graph
// Pin 2 represents the Least Significant Bit (LSB) -> 2^0
// Pin 11 represents the Most Significant Bit (MSB) -> 2^9
const int ledPins[10] = {2, 3, 4, 5, 6, 7, 8, 9, 10, 11};

void setup() {
  // Initialize all 10 pins as OUTPUT
  for (int i = 0; i < 10; i++) {
    pinMode(ledPins[i], OUTPUT);
    digitalWrite(ledPins[i], LOW); // Start with all LEDs off
  }
}

void loop() {
  // Loop from 0 to 1023 (1024 total states)
  for (int count = 0; count <= 1023; count++) {
    displayBinary(count);
    delay(50); // Adjust this delay (in ms) to speed up or slow down the counter
  }
}

// Function to isolate each bit of the number and write it to the respective pin
void displayBinary(int num) {
  for (int i = 0; i < 10; i++) {
    // Read the i-th bit of the number
    int bitState = bitRead(num, i); 
    
    // Send the bit state (HIGH or LOW) to the corresponding pin
    digitalWrite(ledPins[i], bitState);
  }
}
