const int ledPins[10] = {2, 3, 4, 5, 6, 7, 8, 9, 10, 11};

void setup() {
  Serial.begin(9600); // Initialize serial communication at 9600 bps
  
  for (int i = 0; i < 10; i++) {
    pinMode(ledPins[i], OUTPUT);
    digitalWrite(ledPins[i], LOW);
  }
}

void loop() {
  // Check if data is available from the PC
  if (Serial.available() > 0) {
    // Read the incoming number until a newline character is found
    int count = Serial.parseInt();
    
    // Discard any remaining characters like '\n' or '\r'
    if (Serial.read() == '\n') {
      displayBinary(count);
    }
  }
}

void displayBinary(int num) {
  for (int i = 0; i < 10; i++) {
    int bitState = bitRead(num, i);
    digitalWrite(ledPins[i], bitState);
  }
}
